var msg91=require('msg91-sms');
var express = require("express");
var router  = express.Router();
 var multer = require('multer');
var Plumber = require("../models/plumber");
var middleware = require("../middleware");
 var ejs = require('ejs');
 var path = require('path');


  var app = express();

 //EJS

 app.set('view engine', 'ejs');

  //Set Storage Engine
 var storage = multer.diskStorage({
   destination: "./public/uploads/",
   filename: function(req, file, cb){
     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
   }
 });

 // Init Upload
 var upload = multer({
  storage: storage,
  limits:{fileSize: 10000000},
  fileFilter: function(req, file, cb){
    checkFileType(file, cb);
  }
 }).single('myImage');

 //Check File Type

 function checkFileType(file, cb){
  // Allowed ext
  var filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  var extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    // Check mime
    var mimetype = filetypes.test(file.mimetype);

    if(mimetype && extname){
      return cb(null, true);
    } else{
      cb('Error: Images Only!');
    }
 }


// INDEX- show all doctors

router.get("/", function(req,res){

  Plumber.find({},function(err,allPlumbers){
     if(err){
      console.log(err);
     }
     else{
      res.render("plumbers/index",{plumbers:allPlumbers});
     }
  });
});

router.get("/fix/:curr",function(req,res){
var number1;

Plumber.findById(req.params.curr,function(err,number){
  if(err){
      console.log(err);
     }
     else{
       console.log(number)
      console.log(number.mobile)
      console.log('hi'+req.user.mobile )
  number1=number.mobile;
 
  console.log(number.name)
     }
     
     var authkey='208706AgYQ5N3M5acaf0e7';
 
//for multiple numbers 

 
//message 
var message1='hi '+ req.user.fullname + ', Your Appointment has been fixed Please Contact with' + number;
 var message2='hi '+ number.name + ', Your Appointment has been fixed Please Contact with' + req.user.mobile;
//Sender ID 
var senderid='GuardianEye';
 
//Route 
var route='1';
 
//Country dial code 
var dialcode='0';
 
 
//send to single number 
 
msg91.sendOne(authkey,number1,message2,senderid,route,dialcode,function(response){
 
//Returns Message ID, If Sent Successfully or the appropriate Error Message 
console.log('check'+response);
});


msg91.sendOne(authkey,req.user.mobile,message1,senderid,route,dialcode,function(response){
 
//Returns Message ID, If Sent Successfully or the appropriate Error Message 
console.log('check'+response);
});
 





 
});
res.render("success");



});
// show form to create new Doctor


//CREATE - add new doctors to database
router.post("/", middleware.isLoggedIn, function(req,res){

    upload(req, res, (err) => {
     if(err){
      res.render('plumbers/new',{msg : err});
     } else{
      if(req.file == undefined){
            res.render('plumbers/new', {msg: 'Error: No File Selected!'});
      } else{
        var locat = 'uploads/' + `${req.file.filename}`;

    var name = req.body.name;
     var image = locat;
     var desc = req.body.description;
     var author = {
        id: req.user._id,
        username: req.user.username
     }

     var newPlumber = {name: name, image: image, description: desc, author: author}
     Plumber.create(newPlumber,function(err,newlyCreated){
        if(err){
          console.log(err);
        }
        else{
          res.redirect("/plumbers");
        }
     });


/*        res.render('index',{msg: 'File Uploaded!',
        file: locat});*/
      }
     }
   });


});

router.get("/new", middleware.isLoggedIn, function(req,res){
     res.render("plumbers/new");
});


router.get("/:id",function(req,res){
  Plumber.findById(req.params.id).populate("comments").exec(function(err,foundPlumber){
    if(err){
      console.log(err);
    }
    else{
      res.render("plumbers/show",{plumber:foundPlumber});
      //console.log(foundDoctor);
    }
  });
});


// EDIT DOCTOR

 router.get("/:id/edit", middleware.checkPlumberOwnership, function(req, res){
       Plumber.findById(req.params.id, function(err, foundPlumber){
           res.render("plumbers/edit", {plumber: foundPlumber});
       });
 });

 // UPGRADE DOCTOR ROUTE

router.put("/:id", middleware.checkPlumberOwnership, function(req, res){

      upload(req, res, (err) => {
     if(err){
      res.render('plumbers/edit',{msg : err});
     } else{
      if(req.file == undefined){
            res.render('plumbers/edit', {msg: 'Error: No File Selected!'});
      } else{
        var locat = 'uploads/' + `${req.file.filename}`;

      var author = {
        id: req.user._id,
        username: req.user.username
     }

       var newPlumber = {name: req.body.plumber.name, image: locat, description: req.body.plumber.description, author: author};

  Plumber.findByIdAndUpdate(req.params.id, newPlumber, function(err, updatedPlumber){
      if(err){
    res.redirect("/plumbers");
     } else{
    res.redirect("/plumbers/" + req.params.id);
    }
  });
 }
}
});

 });

 // DESTROY DOCTOR ROUTE

 router.delete("/:id", middleware.checkPlumberOwnership, function(req, res){
    Plumber.findByIdAndRemove(req.params.id, function(err){
      if(err){
        res.redirect("/plumbers");
      } else{
        res.redirect("/plumbers");
      }
    });
 });


module.exports = router;