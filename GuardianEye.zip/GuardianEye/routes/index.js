var express     =  require("express");
var router      =  express.Router();
var passport    =  require("passport");
var User        =  require("../models/user");
var otpObject =require("../models/otp");

 
 const SendOtp = require('sendotp');
var verify=false;
var otp=Math.floor(Math.random()*10000);
var data1={
	otp:otp
}
	
 const sendOtp = new SendOtp('204502Aj1IzShH5aafec9a','Your OTP is {{otp}}, Please do not share it with Anybody');


router.get("/",function(req,res){
	res.render("home");

});

router.get("/login",function(req,res){
	res.render("login");

});

router.get("/signup",function(req,res){
	res.render("signup");

});

router.get("/joinus",function(req,res){
	res.render("joinus");

});
router.get("/help",function(req,res){
	res.render("help_center");

});



router.get("/water", function(req,res){
   res.render("water");
});

router.post("/otp",function(req,res){
	var x;

	console.log("check1");
	console.log(req.body.mob);
	var otpes= {mobile:req.body.mob,otp:otp};
	console.log(otpes);


	otpObject.create(otpes,function(err,newlyCreated)
	{
		if(err)
		{
			console.log("Error")
		}
		else{
			console.log('hi created'+newlyCreated);
			newlyCreated.save();
		}
	});

	otpObject.findOne({ mobile:req.body.mob }, function (err, otps) {
	 	if(err)
	 	{
	 		console.log(err);
	 	}
 else{
 	console.log("its set");
 	console.log(otps);
 	
 }
});
	
	
		sendOtp.send(req.body.mob, "GuardianEye",otp, function (error, data, response) {
    console.log(data);
    console.log(data1.otp);
    res.send(data1);
});

});




//auth routes
router.post("/signup",function(req,res){
var newUser	= new User({username: req.body.username, mobile: req.body.mobile, fullname:req.body.name});
User.register(newUser,req.body.password,function(err,user){

	if(err)
	{
		req.flash("error", err.message);
		console.log(err);
		return res.render("signup")
	}
	passport.authenticate("local")(req,res,function(){
	    req.flash("success", "Welcome to GuardianEye " + user.username);
		res.redirect("/doctors");
	});
});

});


router.post("/login",passport.authenticate("local",{
	successRedirect: "/",
	failureRedirect:"/login"
}),function(req,res){


});

router.get("/logout",function(req,res){
	req.logout();
	req.flash("success", "Logged you out!");
	res.redirect("/doctors");

});


function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
res.redirect("/login");
}


module.exports=router;