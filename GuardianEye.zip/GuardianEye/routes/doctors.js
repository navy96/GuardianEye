
var express = require("express");
var router  = express.Router();
 var multer = require('multer');
var Doctor = require("../models/doctor");
var middleware = require("../middleware");
 var ejs = require('ejs');
 var path = require('path');
 var msg91=require('msg91-sms');


  var app = express();

 //EJS

 app.set('view engine', 'ejs');

  //Set Storage Engine
 var storage = multer.diskStorage({
   destination: "./public/uploads/",
   filename: function(req, file, cb){
     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
   }
 });

 // Init Upload
 var upload = multer({
  storage: storage,
  limits:{fileSize: 10000000},
  fileFilter: function(req, file, cb){
    checkFileType(file, cb);
  }
 }).single('myImage');

 //Check File Type

 function checkFileType(file, cb){
  // Allowed ext
  var filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  var extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    // Check mime
    var mimetype = filetypes.test(file.mimetype);

    if(mimetype && extname){
      return cb(null, true);
    } else{
      cb('Error: Images Only!');
    }
 }


// INDEX- show all doctors

router.get("/", function(req,res){

  Doctor.find({},function(err,allDoctors){
     if(err){
      console.log(err);
     }
     else{
      res.render("doctors/index",{doctors:allDoctors});
     }
  });
});
router.get("/fix/:curr",function(req,res){
var number1;

Doctor.findById(req.params.curr,function(err,number){
  if(err){
      console.log(err);
     }
     else{
       console.log(number)
      console.log(number.mobile)
      console.log('hi'+req.user.mobile )
  number1=number.mobile;
 
  console.log(number.name)
     }
     
     var authkey='208706AgYQ5N3M5acaf0e7';
 
//for multiple numbers 

 
//message 
var message1='hi '+ req.user.fullname + ', Your Appointment has been fixed Please Contact with' + number;
 var message2='hi '+ number.name + ', Your Appointment has been fixed Please Contact with' + req.user.mobile;
//Sender ID 
var senderid='GuardianEye';
 
//Route 
var route='1';
 
//Country dial code 
var dialcode='0';
 
 
//send to single number 
 
msg91.sendOne(authkey,number1,message2,senderid,route,dialcode,function(response){
 
//Returns Message ID, If Sent Successfully or the appropriate Error Message 
console.log('check'+response);
});


msg91.sendOne(authkey,req.user.mobile,message1,senderid,route,dialcode,function(response){
 
//Returns Message ID, If Sent Successfully or the appropriate Error Message 
console.log('check'+response);
});
 





 
});
res.send("hi");



});

// show form to create new Doctor


//CREATE - add new doctors to database
router.post("/", middleware.isLoggedIn, function(req,res){

    upload(req, res, (err) => {
     if(err){
      res.render('doctors/new',{msg : err});
     } else{
      if(req.file == undefined){
            res.render('doctors/new', {msg: 'Error: No File Selected!'});
      } else{
        var locat = 'uploads/' + `${req.file.filename}`;

    var name = req.body.name;
     var image = locat;
     var desc = req.body.description;
     var author = {
        id: req.user._id,
        username: req.user.username
     }

     var newDoctor = {name: name, image: image, description: desc, author: author}
     Doctor.create(newDoctor,function(err,newlyCreated){
        if(err){
          console.log(err);
        }
        else{
          res.redirect("/doctors");
        }
     });


/*        res.render('index',{msg: 'File Uploaded!',
        file: locat});*/
      }
     }
   });


});

router.get("/new", middleware.isLoggedIn, function(req,res){
     res.render("doctors/new");
});


router.get("/:id",function(req,res){
  Doctor.findById(req.params.id).populate("comments").exec(function(err,foundDoctor){
    if(err){
      console.log(err);
    }
    else{
      res.render("doctors/show",{doctor:foundDoctor});
      //console.log(foundDoctor);
    }
  });
});


// EDIT DOCTOR

 router.get("/:id/edit", middleware.checkDoctorOwnership, function(req, res){
       Doctor.findById(req.params.id, function(err, foundDoctor){
           res.render("doctors/edit", {doctor: foundDoctor});
       });
 });

 // UPGRADE DOCTOR ROUTE

 router.put("/:id", middleware.checkDoctorOwnership, function(req, res){

      upload(req, res, (err) => {
     if(err){
      res.render('doctors/edit',{msg : err});
     } else{
      if(req.file == undefined){
            res.render('doctors/edit', {msg: 'Error: No File Selected!'});
      } else{
        var locat = 'uploads/' + `${req.file.filename}`;

      var author = {
        id: req.user._id,
        username: req.user.username
     }

       var newDoctor = {name: req.body.doctor.name, image: locat, description: req.body.doctor.description, author: author};

  Doctor.findByIdAndUpdate(req.params.id, newDoctor, function(err, updatedDoctor){
      if(err){
    res.redirect("/doctors");
     } else{
    res.redirect("/doctors/" + req.params.id);
    }
  });
 }
}
});

 });


 // DESTROY DOCTOR ROUTE

 router.delete("/:id", middleware.checkDoctorOwnership, function(req, res){
    Doctor.findByIdAndRemove(req.params.id, function(err){
      if(err){
        res.redirect("/doctors");
      } else{
        res.redirect("/doctors");
      }
    });
 });


module.exports = router;