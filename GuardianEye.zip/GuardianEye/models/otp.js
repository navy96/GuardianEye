var mongoose= require("mongoose");


var otp= mongoose.Schema({
  mobile:String,
 otp:String
});

module.exports=mongoose.model("otp",otp);