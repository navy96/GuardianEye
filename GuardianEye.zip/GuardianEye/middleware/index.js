var Doctor = require("../models/doctor");
var Electrician = require("../models/electrician");
var Plumber = require("../models/plumber");
var Comment = require("../models/comment");

// all the middleware goes here

var middlewareObj = {};

middlewareObj.checkDoctorOwnership = function(req, res, next){
   if(req.isAuthenticated()){
    Doctor.findById(req.params.id, function(err, foundDoctor){
      if(err){
        req.flash("error", "Campground not found");
        res.redirect("back");
      } else{
        if(foundDoctor.author.id.equals(req.user._id)){
          next();
        } else{
          req.flash("error", "You don't have permission to do that");
          res.redirect("back");
        }
      }
    });
   } else{
      req.flash("error", "You need to be logged in to do that");
      res.redirect("back");
   }
}


middlewareObj.checkPlumberOwnership = function(req, res, next){
   if(req.isAuthenticated()){
    Plumber.findById(req.params.id, function(err, foundPlumber){
      if(err){
        req.flash("error", "Plumber not found");
        res.redirect("back");
      } else{
        if(foundPlumber.author.id.equals(req.user._id)){
          next();
        } else{
          req.flash("error", "You don't have permission to do that");
          res.redirect("back");
        }
      }
    });
   } else{
      req.flash("error", "You need to be logged in to do that");
      res.redirect("back");
   }
}


middlewareObj.checkElectricianOwnership = function(req, res, next){
   if(req.isAuthenticated()){
    Electrician.findById(req.params.id, function(err, foundElectrician){
      if(err){
        req.flash("error", "Electrician not found");
        res.redirect("back");
      } else{
        if(foundElectrician.author.id.equals(req.user._id)){
          next();
        } else{
          req.flash("error", "You don't have permission to do that");
          res.redirect("back");
        }
      }
    });
   } else{
      req.flash("error", "You need to be logged in to do that");
      res.redirect("back");
   }
}

middlewareObj.checkCommentOwnership = function(req, res, next){
   if(req.isAuthenticated()){
    Comment.findById(req.params.comment_id, function(err, foundComment){
      if(err){
        res.redirect("back");
      } else{
        if(foundComment.author.id.equals(req.user._id)){
          next();
        } else{
          req.flash("error", "You dont have permission to do that");
          res.redirect("back");
        }
      }
    });
   } else{
      req.flash("error", "You need to be logged in to do that");
      res.redirect("back");
   }
}

//MIDDLEWARE


middlewareObj.isLoggedIn = function(req, res, next){
   if(req.isAuthenticated()){
    return next();
   }
   req.flash("error", "You need to be logged in to do that");
   res.redirect("/login");
}

module.exports = middlewareObj;